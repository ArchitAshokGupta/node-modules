## 1.0.8
* @joaoe fixed a bug with pythonshell not working with unset std streams
* https://github.com/extrabacon/python-shell/milestone/9

## 1.0.7
* default python path updated to py on windows

## 1.0.4
* added getVersionSync

## 0.0.3
* fixed buffering in `PythonShell.receive`, fixing [#1](https://github.com/extrabacon/python-shell/issues/1)

## 0.0.2
* improved documentation

## 0.0.1
* initial version
* independent module moved from [extrabacon/pyspreadsheet](https://github.com/extrabacon/pyspreadsheet)

