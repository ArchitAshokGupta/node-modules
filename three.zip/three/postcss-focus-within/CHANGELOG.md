# Changes to PostCSS Focus Within

### 3.0.0 (September 17, 2018)

- Updated: Support for PostCSS v7+
- Updated: Support for Node v6+

### 2.0.0 (April 7, 2018)

- Changed: default functionality to preserve the original rule
- Added: `preserve` option to preserve the original rule using `:focus-within`

### 1.0.0 (February 17, 2018)

- Initial version
