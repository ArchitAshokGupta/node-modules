export const NODE_TYPE = Symbol.for('NODE_TYPE')
export const VISITOR_KEYS = Symbol.for('VISITOR_KEYS')
