export declare class OperationCanceledException {
}
