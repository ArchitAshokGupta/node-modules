# aria-query Change Log

## 1.0.0

- Updated values of aria-haspopup to include ARIA 1.1 role values
- Added the CHANGELOG file

## 2.0.0

- Remove package-lock file.
- Add Watchman config file.

## 2.0.1

- Added aria-errormessage to the ARIA Props Map.

## 3.0.0

- Bumping to a major version because of a previous breaking change.
